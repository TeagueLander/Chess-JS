var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    }
};

app.initialize();

function init() {
		
	var stage = new createjs.Stage("demoCanvas");
	var circle = new createjs.Shape();
	circle.graphics.beginFill("red").drawCircle(0,0,50);
	circle.x = 100;
	circle.y = 100;
	stage.addChild(circle);
		
	//stage.update();
	
	createjs.Tween.get(circle)
		.to({x:400}, 2000, createjs.Ease.getPowInOut(4))
		.to({alpha:0, y:75}, 500, createjs.Ease.getPowInOut(2))
		.to({alpha: 0, y:125}, 100)
		.to({alpha: 1, y:100}, 500, createjs.Ease.getPowInOut(2))
		.to({x:100}, 800, createjs.Ease.getPowInOut(2))
		;
			
	createjs.Ticker.setFPS(60);
	createjs.Ticker.addEventListener("tick",stage);
			
}

var soundID = "groove";

function loadSound() {
	createjs.Sound.registerSound("../assets/groove.mp3", soundID);
}
		
function playSound() {
	createjs.Sound.play(soundID);
}